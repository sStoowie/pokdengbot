
import discord
import random

client = discord.Client(intents=discord.Intents.default())

rank = ["A", "K", "Q", "J", "10", "9", "8", "7", "6", "5", "4", "3", "2"]
add = ["♠️", "♥️", "♣", "♦️"]
card = random.choice(add)+random.choice(rank)

@client.event
async def on_ready():
    print('Ready')

client.run('MTA1MDA5MzgyMTEyMTI3MzkwNg.GI54x-.qoZ30dFRNYAkAFbJLQoKp3vqtJePgQ5Avk5OVg')
